#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_timer.h"

#define LED_GPIO        GPIO_NUM_2
#define BUTTON_GPIO     GPIO_NUM_4

#define DEBOUNCE_TIME_MS    50
#define AUTO_OFF_TIME_MS    10000

void app_main(void)
{
    // Configuração do LED como saída
    gpio_config_t led_config = {
        .pin_bit_mask = (1ULL << LED_GPIO),
        .mode = GPIO_MODE_OUTPUT,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE
    };
    gpio_config(&led_config);

    // Configuração do botão como entrada com pull-up interno
    gpio_config_t button_config = {
        .pin_bit_mask = (1ULL << BUTTON_GPIO),
        .mode = GPIO_MODE_INPUT,
        .pull_up_en = GPIO_PULLUP_ENABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE
    };
    gpio_config(&button_config);

    bool led_state = false;
    bool last_button_reading = 1;          // botão solto por causa do pull-up
    bool stable_button_state = 1;
    int64_t last_debounce_time = 0;
    int64_t led_on_time = 0;

    gpio_set_level(LED_GPIO, 0);

    while (1) {
        bool current_reading = gpio_get_level(BUTTON_GPIO);
        int64_t now = esp_timer_get_time() / 1000; // em ms

        // Detecta mudança no sinal do botão
        if (current_reading != last_button_reading) {
            last_debounce_time = now;
        }

        // Só considera válida a mudança se permanecer estável por DEBOUNCE_TIME_MS
        if ((now - last_debounce_time) > DEBOUNCE_TIME_MS) {
            if (current_reading != stable_button_state) {
                stable_button_state = current_reading;

                // Como está em pull-up:
                // botão pressionado = 0
                if (stable_button_state == 0) {
                    led_state = !led_state;
                    gpio_set_level(LED_GPIO, led_state);

                    if (led_state) {
                        led_on_time = now;  // inicia contagem dos 10 segundos
                    }
                }
            }
        }

        last_button_reading = current_reading;

        // Temporizador de segurança
        if (led_state && ((now - led_on_time) >= AUTO_OFF_TIME_MS)) {
            led_state = false;
            gpio_set_level(LED_GPIO, 0);
        }

        // Pequeno atraso para reduzir uso da CPU sem perder responsividade
        vTaskDelay(pdMS_TO_TICKS(10));
    }
}