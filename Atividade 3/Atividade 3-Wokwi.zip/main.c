#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/ledc.h"

#define LED1 4
#define LED2 5
#define LED3 6
#define LED4 7
#define BUZZER 15

#define DELAY_MS 500

void app_main(void)
{

    ledc_timer_config_t timer = {
        .speed_mode = LEDC_LOW_SPEED_MODE,
        .timer_num = LEDC_TIMER_0,
        .duty_resolution = LEDC_TIMER_10_BIT,
        .freq_hz = 1000,
        .clk_cfg = LEDC_AUTO_CLK
    };

    ledc_timer_config(&timer);

    int pins[5] = {LED1, LED2, LED3, LED4, BUZZER};

    for(int i=0;i<5;i++){
        ledc_channel_config_t channel = {
            .gpio_num = pins[i],
            .speed_mode = LEDC_LOW_SPEED_MODE,
            .channel = i,
            .timer_sel = LEDC_TIMER_0,
            .duty = 0,
            .hpoint = 0
        };

        ledc_channel_config(&channel);
    }

    while (1)
    {

        // FASE 1 - Fade sincronizado
        for(int duty=0; duty<1023; duty+=80){
            for(int i=0;i<4;i++){
                ledc_set_duty(LEDC_LOW_SPEED_MODE, i, duty);
                ledc_update_duty(LEDC_LOW_SPEED_MODE, i);
            }
            vTaskDelay(pdMS_TO_TICKS(DELAY_MS));
        }

        for(int duty=1023; duty>0; duty-=80){
            for(int i=0;i<4;i++){
                ledc_set_duty(LEDC_LOW_SPEED_MODE, i, duty);
                ledc_update_duty(LEDC_LOW_SPEED_MODE, i);
            }
            vTaskDelay(pdMS_TO_TICKS(DELAY_MS));
        }


        // FASE 2 - LEDs sequenciais
        for(int i=0;i<4;i++){

            ledc_set_duty(LEDC_LOW_SPEED_MODE, i, 1023);
            ledc_update_duty(LEDC_LOW_SPEED_MODE, i);

            vTaskDelay(pdMS_TO_TICKS(300));

            ledc_set_duty(LEDC_LOW_SPEED_MODE, i, 0);
            ledc_update_duty(LEDC_LOW_SPEED_MODE, i);
        }


        // FASE 3 - Buzzer variando frequência
        for(int freq=500; freq<=2000; freq+=100){

            ledc_set_freq(LEDC_LOW_SPEED_MODE, LEDC_TIMER_0, freq);

            ledc_set_duty(LEDC_LOW_SPEED_MODE, 4, 512);
            ledc_update_duty(LEDC_LOW_SPEED_MODE, 4);

            vTaskDelay(pdMS_TO_TICKS(100));
        }

        ledc_set_duty(LEDC_LOW_SPEED_MODE, 4, 0);
        ledc_update_duty(LEDC_LOW_SPEED_MODE, 4);
    }
}